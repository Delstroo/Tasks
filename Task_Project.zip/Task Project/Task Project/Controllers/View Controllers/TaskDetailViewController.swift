//
//  TaskDetailViewController.swift
//  Task Project
//
//  Created by Lon Chandler Madsen on 7/21/21.
//

import UIKit

class TaskDetailViewController: UIViewController {
    
    //MARK: - Outlets

    
    @IBOutlet weak var taskNameTextField: UITextField!
    
    @IBOutlet weak var taskNotesTextView: UITextView!
    
    @IBOutlet weak var taskDueDatePicker: UIDatePicker!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateViews()
    }
    
    var task: Task?
    var date: Date?
    
    //MARK: - Actions
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        
        guard let title = taskNameTextField.text, !title.isEmpty,
              let notes = taskNotesTextView.text, !notes.isEmpty else {return}
        if let task = task {
            task.name = title
            task.notes = notes
            task.dueDate = date
            TaskController.sharedInstance.update(task: task, name: title, notes: notes, dueDate: date)
        } else { TaskController.sharedInstance.createTaskWith(name: title, notes: notes, dueDate: date)
            }
        self.navigationController?.popViewController(animated: true)
            
        }
              
    @IBAction func dueDatePickerDateChanged(_ sender: Any) {
        self.date = taskDueDatePicker.date
    }
    
    func updateViews() {
        guard let task = task else {return}
        taskNameTextField.text = task.name
        taskNotesTextView.text = task.notes
        taskDueDatePicker.date = task.dueDate ?? Date()
        
    }
}
