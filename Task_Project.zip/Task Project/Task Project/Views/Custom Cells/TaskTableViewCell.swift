//
//  TaskTableViewCell.swift
//  Task Project
//
//  Created by Lon Chandler Madsen on 7/21/21.
//
//
import UIKit

protocol TaskCellDelegate: AnyObject {
    func completionButtonTapped(for cell: TaskTableViewCell)
}

class TaskTableViewCell: UITableViewCell {

    @IBOutlet weak var taskNameLabel: UILabel!
    
    @IBOutlet weak var completionButton: UIButton!
    
    
    //MARK: - delegate
    weak var delegate: TaskCellDelegate?
    
    
    @IBAction func completionButtonTapped(_ sender: Any) {
        delegate?.completionButtonTapped(for: self)
    }
    
    func updateViews(with task: Task) {
        
        taskNameLabel.text = task.name
        let incomplete = UIImage(named: "incomplete")
        let complete = UIImage(named: "complete")
        task.isComplete ? completionButton.setImage(complete, for: .normal) : completionButton.setImage(incomplete, for: .normal)
        
        
      
        
    }
  
    
  
}
